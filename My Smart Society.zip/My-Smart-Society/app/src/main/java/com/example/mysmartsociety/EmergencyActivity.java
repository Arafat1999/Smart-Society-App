package com.example.mysmartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import com.example.mysmartsociety.AppUtils.CategoryPreference;
import com.example.mysmartsociety.AppUtils.ToastUtils;

public class EmergencyActivity extends AppCompatActivity {

    CategoryPreference cPrefrence;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency);

        cPrefrence = CategoryPreference.getInstance(EmergencyActivity.this);
    }

    public void On_Go_Back(View view) {
        super.getClass();
        this.finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public void On_Call_Manager(View view) {
        String value = cPrefrence.getData("c_manager_no");
        ToastUtils.showToastLong(EmergencyActivity.this,"Calling Manager..." );
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:"+value));
        startActivity(intent);
}

    public void On_Call_Secretary(View view) {
        String value = cPrefrence.getData("c_secretory_no");
        ToastUtils.showToastLong(EmergencyActivity.this,"Calling Secretary...");
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:"+value));
        startActivity(intent);
    }

    public void On_Call_Watchman(View view) {
        ToastUtils.showToastLong(EmergencyActivity.this,"Calling Watchman...");
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:9167908881"));
        startActivity(intent);
    }

    public void On_Call_Plumber(View view) {
        ToastUtils.showToastLong(EmergencyActivity.this,"Calling Plumber...");
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:9167908881"));
        startActivity(intent);
    }

    public void On_Call_Electrician(View view) {
        ToastUtils.showToastLong(EmergencyActivity.this,"Calling Electrician...");
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:9167908881"));
        startActivity(intent);
    }

    public void On_Call_Ambulance(View view) {
        ToastUtils.showToastLong(EmergencyActivity.this,"Calling Ambulance...");
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:9167908881"));
        startActivity(intent);
    }

    public void On_Call_Police(View view) {
        ToastUtils.showToastLong(EmergencyActivity.this,"Calling Police...");
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:9167908881"));
        startActivity(intent);
    }

    public void On_Call_Fire_Brigade(View view) {
        ToastUtils.showToastLong(EmergencyActivity.this,"Calling Fire-Brigade...");
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:9167908881"));
        startActivity(intent);
    }
}