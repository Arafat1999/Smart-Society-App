package com.example.mysmartsociety;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.mysmartsociety.AppUtils.CategoryPreference;
import com.example.mysmartsociety.AppUtils.CheckInternetConnectivity;
import com.example.mysmartsociety.AppUtils.ToastUtils;
import com.example.mysmartsociety.Model.PayActivity;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.common.reflect.TypeToken;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.HashMap;
import java.util.Map;

public class HomeActivity extends AppCompatActivity {

    private static final String TAG = HomeActivity.class.getName();

    private FirebaseAuth mAuth;
    FirebaseUser user;
    GoogleSignInClient mGoogleSignInClient;

    LinearLayout dialog_layout;
    TextView UserEmail, UserType;

    CategoryPreference cPrefrence;
    String UserTypeValue;
    Button Notice, Complaints,Pay;

    private FirebaseDatabase db = FirebaseDatabase.getInstance();
    private DatabaseReference visitorsRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mAuth = FirebaseAuth.getInstance();

        FirebaseMessaging.getInstance().subscribeToTopic("all");

        dialog_layout = (LinearLayout) findViewById(R.id.dialog_layout);
        UserEmail = findViewById(R.id.user_email);
        UserType = findViewById(R.id.user_type);

        cPrefrence = CategoryPreference.getInstance(HomeActivity.this);

        UserTypeValue = cPrefrence.getData("c_user_type");
        UserType.setText(UserTypeValue);

        //if logged in as Secretory
        if(UserTypeValue.equals("Secretory")){
            Notice = findViewById(R.id.btn_notices);
            Pay = findViewById(R.id.btn_pay_maintenance);
            Complaints = findViewById(R.id.btn_complaints);

            Notice.setText("Add Notices");
            Pay.setText("Pay");
            Complaints.setText("List of Complaints");
        }
    }

    private void updateUI(FirebaseUser user) {
        // hideProgressBar();
        if (user != null) {
            UserEmail.setText(user.getEmail());
        } else {
            UserEmail.setText(null);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        updateUI(currentUser);
    }

    //dialog open
    public void On_Open_Dialog(View view) {
        if (dialog_layout.getVisibility() == View.GONE) {
            dialog_layout.setVisibility(View.VISIBLE);
        }
    }

    //dialog close
    public void On_Inner_Dilaog_Layout(View view) {
        if (dialog_layout.getVisibility() == View.VISIBLE) {
            dialog_layout.setVisibility(View.GONE);
        }
    }

    public void On_Logout(View view) {
        if (CheckInternetConnectivity.isInternet(HomeActivity.this)) {
            if (mAuth.getCurrentUser() != null) {
                FirebaseAuth.getInstance().signOut();
                UserEmail.setText(null);
                cPrefrence.clearData();
                ToastUtils.showToastShort(HomeActivity.this, "You have successfully Logout!");
                this.finish();
                startActivity(new Intent(HomeActivity.this,LoginActivity.class));
            }else if(user != null){
                mGoogleSignInClient.signOut().addOnCompleteListener(this,
                        new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                UserEmail.setText(null);
                            }
                        });
                this.finish();
                startActivity(new Intent(HomeActivity.this,LoginActivity.class));
                ToastUtils.showToastShort(HomeActivity.this, "You have successfully Logout!");
            }
            else {
                ToastUtils.showToastShort(HomeActivity.this, "Unable to Logout!");
            }
        } else {
            ToastUtils.showToastLong(HomeActivity.this, "No Internet Connection!!!");
        }
    }

    public void On_Notification(View view) {
        startActivity(new Intent(HomeActivity.this, NotificationActivity.class));
    }

    public void On_Visitor_List(View view) {
        startActivity(new Intent(HomeActivity.this, VisitorListActivity.class));
    }

    //society details
    public void On_Society_Details(View view) {
        On_Inner_Dilaog_Layout(view);
        startActivity(new Intent(HomeActivity.this, MySocietyDetailsActivity.class));
    }

    //notice btn
    public void On_Notices(View view) {
        if(UserTypeValue.equals("Secretory")){
            startActivity(new Intent(HomeActivity.this,NoticesActivity.class ));
        }else{
            startActivity(new Intent(HomeActivity.this, ViewAllNoticesActivity.class ));
        }

    }

    //complaints btn
    public void On_Add_Complaints(View view) {
        if(UserTypeValue.equals("Secretory")){
            startActivity(new Intent(HomeActivity.this, AddComplaintsActivity.class));
        }else{
            startActivity(new Intent(HomeActivity.this, AddComplaintsActivity.class));
        }
    }
    //Pay btn
    public void On_Pay(View view){
        startActivity(new Intent(HomeActivity.this, PayActivity.class));
    }

    //emergency btn
    public void On_Emergency_Contact(View view) {
        startActivity(new Intent(HomeActivity.this, EmergencyActivity.class));
    }

    //Scan gate pass
    public void On_Scan_Gatepass(View view) {
        IntentIntegrator intentIntegrator = new IntentIntegrator(HomeActivity.this);
        intentIntegrator.setDesiredBarcodeFormats(intentIntegrator.QR_CODE_TYPES);
        intentIntegrator.setBeepEnabled(true);
        intentIntegrator.setCameraId(0);
        intentIntegrator.setPrompt("SCANNING GATE-PASS...");
        intentIntegrator.setBarcodeImageEnabled(false);
        intentIntegrator.initiateScan();
    }

    //after scanning the QR Code this method get the result and check
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult Result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (Result != null) {
            if (Result.getContents() == null) {
                //if scanning process cancelled by the user
                ToastUtils.showToastShort(HomeActivity.this, "Process Cancelled!");
            } else {
                //check society member using unique code if is valid or not
                try {
                    Gson g = new Gson();
                    JsonObject object = g.fromJson(Result.getContents(), JsonObject.class);

                    ToastUtils.showToastShort(HomeActivity.this, "You have Successfully Verified");
                    visitorsRef = db.getReference().child("visitors"+"/"+object.get("Society_unique_code").getAsString());

                    String id = visitorsRef.push().getKey();
                    object.addProperty("id" , id);
                    object.addProperty("checkInTimestamp" , System.currentTimeMillis());

                    HashMap<String, Object> mapObj = new Gson().fromJson(
                            object, new TypeToken<HashMap<String, Object>>() {}.getType()
                    );
                    visitorsRef.child(id).setValue(mapObj);

                    Intent intent = new Intent(HomeActivity.this, VisitorDetailActivity.class);
                    intent.putExtra("data", mapObj);
                    startActivity(intent);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                    ToastUtils.showToastShort(HomeActivity.this, "Sorry, unable to verify!");
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (dialog_layout.getVisibility() == View.VISIBLE) {
            dialog_layout.setVisibility(View.GONE);
        } else {
            finish();
        }
    }

    public void On_generate_Gatepass(View view) {
        startActivity(new Intent(HomeActivity.this, CreateVisitorActivity.class));
    }
}