package com.example.mysmartsociety;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.example.mysmartsociety.AppUtils.CategoryPreference;
import com.example.mysmartsociety.AppUtils.CheckInternetConnectivity;
import com.example.mysmartsociety.AppUtils.ToastUtils;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class ChooseCategoryActivity extends AppCompatActivity {


    private FirebaseDatabase db = FirebaseDatabase.getInstance();
    private DatabaseReference root = db.getReference().child("society");

    EditText uniqueCode;
    CategoryPreference cPrefrence;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_category);
        cPrefrence = CategoryPreference.getInstance(ChooseCategoryActivity.this);
        uniqueCode = findViewById(R.id.edt_unique_code);

    }

    public void On_Society_Member(View view) {

        String code = uniqueCode.getText().toString();

        if (CheckInternetConnectivity.isInternet(ChooseCategoryActivity.this)) {

            root.orderByChild("Society_unique_code").equalTo(code).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if(dataSnapshot.exists()) {

                        for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                            Map <String, String> map = (Map)snapshot.getValue();

                            String Suniquecode = map.get("Society_unique_code");
                            String Sname = map.get("Society_name");
                            String Sadd = map.get("Society_add");
                            String Sflats = map.get("Society_flats");
                            String Swings = map.get("Society_wings");
                            String manager = map.get("Society_manager");
                            String secretory = map.get("Society_secretory");

                            cPrefrence.saveData("c_unique_code",Suniquecode);
                            cPrefrence.saveData("c_name",Sname);
                            cPrefrence.saveData("c_add",Sadd);
                            cPrefrence.saveData("c_flats",Sflats);
                            cPrefrence.saveData("c_wings",Swings);
                            cPrefrence.saveData("c_manager_no",manager);
                            cPrefrence.saveData("c_secretory_no",secretory);
                        }

                        cPrefrence.saveData("c_user_type","Society Member");
                        startActivity(new Intent(ChooseCategoryActivity.this, HomeActivity.class));
                        ToastUtils.showToastShort(ChooseCategoryActivity.this, "You have successfully verified ✔");
                        finish();
                    } else{
                        ToastUtils.showToastShort(ChooseCategoryActivity.this, "Invalid Unique Code ❌");
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    ToastUtils.showToastShort(ChooseCategoryActivity.this, "Error:" + databaseError);
                }
            });
        } else {
            ToastUtils.showToastLong(ChooseCategoryActivity.this, "No Internet Connection!!!");
        }
    }

    public void On_Create_Society(View view) {
        startActivity(new Intent(getApplicationContext(), CreateSocietyActivity.class));
    }


    @Override
    public void onBackPressed() {
        Clear_login_Instance();
        ToastUtils.showToastShort(ChooseCategoryActivity.this,"Process cancelled!");
        finish();
    }

   /* @Override
    protected void onDestroy() {
        Clear_login_Instance();
        super.onDestroy();
    }*/

    public void Clear_login_Instance() {
        if (CheckInternetConnectivity.isInternet(ChooseCategoryActivity.this)) {
                FirebaseAuth.getInstance().signOut();
               // ToastUtils.showToastShort(ChooseCategoryActivity.this, "You have successfully Logout!");
                this.finish();
        } else {
            ToastUtils.showToastLong(ChooseCategoryActivity.this, "No Internet Connection!!!");
        }
    }
}