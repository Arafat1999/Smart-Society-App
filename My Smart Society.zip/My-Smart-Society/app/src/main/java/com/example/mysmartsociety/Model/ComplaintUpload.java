package com.example.mysmartsociety.Model;

public class ComplaintUpload {
    String name,complain;

    public String getName() {
        return name;
    }

    public String getComplain() {
        return complain;
    }
}
