package com.example.mysmartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mysmartsociety.AppUtils.NotificationAPI;
import com.example.mysmartsociety.AppUtils.RetrofitInstance;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotificationActivity extends AppCompatActivity {
    private final static String TAG = NotificationActivity.class.getName();

    EditText notificationTitle, notificationDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        notificationTitle=findViewById(R.id.edt_visitor_title);
        notificationDescription=findViewById(R.id.edt_visitor_description_name);
    }

    public void onSend(View view){
        if (notificationTitle.getText().toString().trim().isEmpty()) {
            notificationTitle.setError("Kindly enter notification title");
            return;
        }
        if (notificationDescription.getText().toString().trim().isEmpty()) {
            notificationDescription.setError("Kindly enter notification description");
            return;
        }

        JsonObject object = new JsonObject();

        JsonObject dataObject = new JsonObject();
        dataObject.addProperty("title", notificationTitle.getText().toString());
        dataObject.addProperty("message", notificationDescription.getText().toString());

        object.add("data", dataObject);
        object.addProperty("to", "/topics/all");

        Call<JsonObject> call = new RetrofitInstance().retrofit(getApplicationContext())
                .create(NotificationAPI.class)
                .postNotification(object);
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                Log.d(TAG, "onResponse: "+response.body());
                notificationDescription.setText("");
                notificationTitle.setText("");
                Toast.makeText(getApplicationContext(), "Notification Send", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e(TAG, "onFailure: ", t);
            }
        });
    }

    public void On_Go_Back(View view) {
        this.finish();
    }

}