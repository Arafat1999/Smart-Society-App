package com.example.mysmartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.HashMap;
import java.util.Map;

public class VisitorDetailActivity extends AppCompatActivity {
    private static final String TAG = VisitorDetailActivity.class.getName();


    TextView detailName, detailRoomno, detailReason, detailNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visitor_detail);

        detailName=findViewById(R.id.edt_visitor_detail_name);
        detailRoomno=findViewById(R.id.edt_detail_roomno);
        detailReason=findViewById(R.id.edt_visitor_detail_reason);
        detailNo=findViewById(R.id.edt_visitor_detail_no);

            HashMap<String, String> societyMap = (HashMap<String, String>)getIntent().getSerializableExtra("data");
            Log.d("HashMapTest", societyMap.toString());
        if (societyMap.containsKey("visitorReason")) {
            detailReason.setText(societyMap.get("visitorReason").toString());
        }
        if (societyMap.containsKey("visitorName")) {
            detailName.setText(societyMap.get("visitorName").toString());
        }
        if (societyMap.containsKey("roomno")) {
            detailRoomno.setText(societyMap.get("roomno").toString());
        }
        if (societyMap.containsKey("visitorNo")) {
            detailNo.setText(societyMap.get("visitorNo").toString());
        }
    }
    public void On_Go_Back(View view) {
        this.finish();
    }

}