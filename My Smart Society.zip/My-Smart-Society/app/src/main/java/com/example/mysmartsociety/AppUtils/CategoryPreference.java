package com.example.mysmartsociety.AppUtils;

import android.content.Context;
import android.content.SharedPreferences;

public class CategoryPreference {
    private static CategoryPreference cPreference;
    private SharedPreferences sharedPreferences;

    public static CategoryPreference getInstance(Context context) {
        if (cPreference == null) {
            cPreference = new CategoryPreference(context);
        }
        return cPreference;
    }

    private CategoryPreference(Context context) {
        sharedPreferences = context.getSharedPreferences("c_Preference", Context.MODE_PRIVATE);
    }

    public void saveData(String key, String value) {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putString(key, value);
        prefsEditor.commit();
    }

    public String getData(String key) {
        if (sharedPreferences != null) {
            return sharedPreferences.getString(key, "");
        }
        return "";
    }

    public void clearData() {
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.clear();
        prefsEditor.commit();
    }
}

