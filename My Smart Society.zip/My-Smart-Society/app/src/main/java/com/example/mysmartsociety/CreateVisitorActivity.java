package com.example.mysmartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.mysmartsociety.AppUtils.CategoryPreference;
import com.example.mysmartsociety.AppUtils.CheckInternetConnectivity;
import com.google.gson.JsonObject;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.util.HashMap;
import java.util.Map;

public class CreateVisitorActivity extends AppCompatActivity {
    EditText visitorName, roomno, visitorReason, visitorNo;
    ImageView imageView;

    CategoryPreference cPrefrence;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_visitor);

        cPrefrence = CategoryPreference.getInstance(CreateVisitorActivity.this);

        visitorName=findViewById(R.id.edt_visitor_name);
        roomno=findViewById(R.id.edt_roomno);
        visitorReason=findViewById(R.id.edt_visitor_reason);
        visitorNo=findViewById(R.id.edt_visitor_no);
        imageView = findViewById(R.id.imageView);
    }

    public void onVisitor(View view) {
        if(!CheckInternetConnectivity.isInternet(CreateVisitorActivity.this)) {
            Toast.makeText(this, "Not Internet", Toast.LENGTH_SHORT).show();
            return;
        }
        if (visitorName.getText().toString().isEmpty()) {
            visitorName.setError("Please enter Visitor name");
            return;
        }
        if (roomno.getText().toString().isEmpty()) {
            roomno.setError("Please Enter Room no");
            return;
        }
        if (visitorReason.getText().toString().isEmpty()) {
            visitorReason.setError("Please Enter Reason");
            return;
        }
        if (visitorNo.getText().toString().isEmpty()) {
            visitorNo.setError("Please Enter Phone Number");
            return;
        }
        JsonObject object = new JsonObject();
        object.addProperty("visitorName", visitorName.getText().toString());
        object.addProperty("roomno", roomno.getText().toString());
        object.addProperty("visitorReason", visitorReason.getText().toString());
        object.addProperty("visitorNo", visitorNo.getText().toString());
        object.addProperty("Society_unique_code", cPrefrence.getData("c_unique_code"));
        object.addProperty("email", cPrefrence.getData("c_email"));

        String text = object.toString();

        MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
        try {
            BitMatrix bitMatrix = multiFormatWriter.encode(text, BarcodeFormat.QR_CODE,200,200);
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
            imageView.setImageBitmap(bitmap);
        } catch (WriterException e) {
            e.printStackTrace();
        }
    }
}