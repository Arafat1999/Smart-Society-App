package com.example.mysmartsociety;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import com.example.mysmartsociety.Adapters.ImageAdapter;
import com.example.mysmartsociety.AppUtils.CheckInternetConnectivity;
import com.example.mysmartsociety.AppUtils.ToastUtils;
import com.example.mysmartsociety.Model.Upload;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ViewAllNoticesActivity extends AppCompatActivity implements ImageAdapter.OnItemClickListener {

    private RecyclerView mRecyclerView;
    private ImageAdapter mAdapter;
    private FirebaseStorage mStorage;

    private ProgressBar mProgressCircle;
    private ValueEventListener mDBListener;
    private DatabaseReference mDatabaseRef;
    private List<Upload> mUploads;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all_notices);
        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mProgressCircle = findViewById(R.id.progress_circular);

        mUploads = new ArrayList<>();
        mAdapter = new ImageAdapter(ViewAllNoticesActivity.this, mUploads);
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.setOnItemClickListener(ViewAllNoticesActivity.this);

        mStorage = FirebaseStorage.getInstance();
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("notices_uploads");
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);
        mLayoutManager.setReverseLayout(true);
        mLayoutManager.setStackFromEnd(true);
        // Set the layout manager to your recyclerview
        mRecyclerView.setLayoutManager(mLayoutManager);

        if (CheckInternetConnectivity.isInternet(ViewAllNoticesActivity.this)) {
            ToastUtils.showToastLong(ViewAllNoticesActivity.this, "Please wait loading all notice...");
            mDBListener = mDatabaseRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    mUploads.clear();
                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                        Upload upload = postSnapshot.getValue(Upload.class);
                        upload.setKey(postSnapshot.getKey());
                        mUploads.add(upload);
                    }
                    mAdapter.notifyDataSetChanged();
                    mProgressCircle.setVisibility(View.GONE);
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    ToastUtils.showToastLong(ViewAllNoticesActivity.this, "Error: " + databaseError.getMessage());
                    mProgressCircle.setVisibility(View.GONE);
                }
            });
        } else {
            mProgressCircle.setVisibility(View.GONE);
            ToastUtils.showToastLong(ViewAllNoticesActivity.this, "No Internet Connection!!!");
        }
    }

    public void viewSelectedNotice(int position){
        Upload uploadCur= mUploads.get(position);

        if(uploadCur.getImgUrl() != null){
            Intent intent = new Intent(getApplicationContext(), ViewSelectedNoticeActivity.class);
            intent.putExtra("image_url", uploadCur.getImgUrl());
            intent.putExtra("image_desc", uploadCur.getImgName());
            startActivity(intent);
        }
        else{
            ToastUtils.showToastLong(ViewAllNoticesActivity.this, "Please wait loading image!");
        }
    }

    @Override
    public void onItemClick(int position) {
        viewSelectedNotice(position);
    }

    @Override
    public void onWhatEverClick(int position) {
        viewSelectedNotice(position);
    }

    @Override
    public void onDeleteClick(int position) {
        Upload selectedItem = mUploads.get(position);
        final String selectedKey = selectedItem.getKey();

        StorageReference imageRef = mStorage.getReferenceFromUrl(selectedItem.getImgUrl());
        imageRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                mDatabaseRef.child(selectedKey).removeValue();
                ToastUtils.showToastLong(ViewAllNoticesActivity.this, "Item deleted successfully!");
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDatabaseRef.removeEventListener(mDBListener);
    }

    public void On_Go_Back(View view) {
        super.getClass();
        this.finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
