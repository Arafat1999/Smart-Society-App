package com.example.mysmartsociety;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mysmartsociety.AppUtils.CheckInternetConnectivity;
import com.example.mysmartsociety.AppUtils.ToastUtils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPassActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;

    EditText EdtEmail;
    private ProgressDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_pass);

        mDialog = new ProgressDialog(this);
        EdtEmail=findViewById(R.id.edt_email);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

    }

    public void On_Reset_Password(View view) {
        String mEmail = EdtEmail.getText().toString().trim();
        if(TextUtils.isEmpty(mEmail)) {
            EdtEmail.setError("Please enter email!");
            return;
        }

        if (CheckInternetConnectivity.isInternet(ForgotPassActivity.this)) {
        mDialog.setMessage("Sending Password reset mail...");
        mDialog.show();
        mAuth.sendPasswordResetEmail(mEmail)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()) {
                            ToastUtils.showToastLong(ForgotPassActivity.this, "Password reset mail send successfully!");
                            finish();
                            super.getClass();
                        }else{
                            ToastUtils.showToastLong(ForgotPassActivity.this, "Something went wrong!");
                        }
                        mDialog.dismiss();
                    }
                });
        }else{
            ToastUtils.showToastLong(ForgotPassActivity.this,"No Internet Connection!!!");
        }
    }

    public void On_Login(View view) {
        super.getClass();
        this.finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}