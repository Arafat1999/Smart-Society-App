package com.example.mysmartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mysmartsociety.AppUtils.ToastUtils;
import com.squareup.picasso.Picasso;

public class ViewSelectedNoticeActivity extends AppCompatActivity {

    TextView tv_selected_notice;
    ImageView selected_notice_img;
    String url = "", txt = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_selected_notice);

        url = getIntent().getStringExtra("image_url");
        txt = getIntent().getStringExtra("image_desc");
        selected_notice_img = findViewById(R.id.img_selected_notice);
        tv_selected_notice = findViewById(R.id.txt_selected_notice);

        tv_selected_notice.setText(txt);
        tv_selected_notice.setSelected(true);
        Picasso.get()
                .load(url)
                .placeholder(R.drawable.ic_image_watermark)
                .into(selected_notice_img);
    }

    public void On_Go_Back(View view) {
        super.getClass();
        this.finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

}