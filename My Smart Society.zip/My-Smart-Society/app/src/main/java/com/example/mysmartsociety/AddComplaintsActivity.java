package com.example.mysmartsociety;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.mysmartsociety.AppUtils.CheckInternetConnectivity;
import com.example.mysmartsociety.AppUtils.ToastUtils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class AddComplaintsActivity extends AppCompatActivity {

    private EditText mName , mComplain;
    ProgressBar uploadProgress;

    private FirebaseDatabase db = FirebaseDatabase.getInstance();
    private DatabaseReference root = db.getReference().child("member_complaints");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_complaints);

        uploadProgress  = findViewById(R.id.progress_circular);


        mName = findViewById(R.id.edt_name);
        mComplain = findViewById(R.id.edt_complaint);
    }

    public void Submit_Complaint(View view) {

        if (CheckInternetConnectivity.isInternet(AddComplaintsActivity.this)) {
            if(mName.getText().toString().isEmpty()){
                mName.setError("Please enter name!");
            }else if(mComplain.getText().toString().isEmpty()){
                mComplain.setError("Enter your complain!");
            }else {
                uploadProgress.setVisibility(View.VISIBLE);
                String name = mName.getText().toString();
                String complain = mComplain.getText().toString();

                HashMap<String , String> userMap = new HashMap<>();
                userMap.put("name" , name);
                userMap.put("complain",complain);

                root.push().setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        uploadProgress.setVisibility(View.GONE);
                        ToastUtils.showToastShort(AddComplaintsActivity.this,"Complaint Raised successfully");
                    }
                });
            }
        } else {
            ToastUtils.showToastLong(AddComplaintsActivity.this, "No Internet Connection!!!");
        }

    }

    public void On_Go_Back(View view) {
        super.getClass();
        this.finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public void View_Complaint(View view) {
        startActivity(new Intent(AddComplaintsActivity.this, ViewComplaintsActivity.class));
    }
}