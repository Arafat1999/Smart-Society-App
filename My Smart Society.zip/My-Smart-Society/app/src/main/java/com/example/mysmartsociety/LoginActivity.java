package com.example.mysmartsociety;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.mysmartsociety.AppUtils.CategoryPreference;
import com.example.mysmartsociety.AppUtils.CheckInternetConnectivity;
import com.example.mysmartsociety.AppUtils.ToastUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private final static String TAG = LoginActivity.class.getName();

    private FirebaseAuth mAuth;
    private FirebaseDatabase db = FirebaseDatabase.getInstance();
    private DatabaseReference root = db.getReference().child("society");

    GoogleSignInClient mGoogleSignInClient;
    int RC_SIGN_IN = 0;

    EditText EdtEmail, EdtPass;
    private ProgressDialog mDialog;

    CategoryPreference cPrefrence;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mDialog = new ProgressDialog(this);
        EdtEmail = findViewById(R.id.edt_email);
        EdtPass = findViewById(R.id.edt_pass);

        cPrefrence = CategoryPreference.getInstance(LoginActivity.this);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser() != null) {
            startActivity(new Intent(getApplicationContext(),HomeActivity.class));
            finish();
        }

        //TODO Google Signin not working
        // Configure Google Sign In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(getApplicationContext(), gso);

    }

    public void On_Login(View view) {
        String mEmail = EdtEmail.getText().toString().trim();
        String mPass = EdtPass.getText().toString().trim();
        if (TextUtils.isEmpty(mEmail)) {
            EdtEmail.setError("Please enter email!");
            return;
        } else if (TextUtils.isEmpty(mPass) || mPass.length() == 5) {
            EdtPass.setError("Enter atleast 6 char proper password!");
            return;
        }

        if (CheckInternetConnectivity.isInternet(LoginActivity.this)) {
            mDialog.setMessage("Logging In...");
            mDialog.show();
            mAuth.signInWithEmailAndPassword(mEmail, mPass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        mDialog.dismiss();
                        getSocietyDetails(mEmail);
                    } else {
                        ToastUtils.showToastLong(LoginActivity.this, "Incorrect email or password!");
                        mDialog.dismiss();
                    }
                }
            });
        } else {
            ToastUtils.showToastLong(LoginActivity.this, "No Internet Connection!!!");
        }

    }

    private void getSocietyDetails(String email) {
        Log.d(TAG, "getSocietyDetails: "+email);
        root.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot postSnapshot: dataSnapshot.getChildren()) {
                    Log.d(TAG, "onDataChange: "+postSnapshot.getValue());
                    ObjectMapper oMapper = new ObjectMapper();
                    Map<String, Object> societyMap = oMapper.convertValue(postSnapshot.getValue(), Map.class);
                    if (societyMap.containsKey("email") && societyMap.get("email").toString().equals(email)) {
                        cPrefrence.saveData("c_unique_code",societyMap.get("Society_unique_code").toString());
                        cPrefrence.saveData("c_name",societyMap.get("Society_name").toString());
                        cPrefrence.saveData("c_add",societyMap.get("Society_add").toString());
                        cPrefrence.saveData("c_flats",societyMap.get("Society_flats").toString());
                        cPrefrence.saveData("c_wings",societyMap.get("Society_wings").toString());
                        cPrefrence.saveData("c_manager_no",societyMap.get("Society_manager").toString());
                        cPrefrence.saveData("c_secretory_no",societyMap.get("Society_secretory").toString());
                        cPrefrence.saveData("c_email",societyMap.get("email").toString());

                        ToastUtils.showToastShort(LoginActivity.this,"Login successful");
                        startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                        finishAffinity();
                        return;
                    }
                }
                ToastUtils.showToastShort(LoginActivity.this,"Login successful");
                startActivity(new Intent(getApplicationContext(), ChooseCategoryActivity.class));
                finish();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Getting Post failed, log a message
                Log.w("TAG", "loadPost:onCancelled", databaseError.toException());
                // ...
            }
        });
    }

    public void On_Google_Signin(View view) {
        if (CheckInternetConnectivity.isInternet(LoginActivity.this)) {
            Intent signInIntent = mGoogleSignInClient.getSignInIntent();
            startActivityForResult(signInIntent, RC_SIGN_IN);
        } else {
            ToastUtils.showToastLong(LoginActivity.this, "No Internet Connection!!!");
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                Log.d(TAG, "firebaseAuthWithGoogle:" + account.getId());
                firebaseAuthWithGoogle(account.getIdToken());
            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately
                ToastUtils.showToastLong(LoginActivity.this, "Google sign in failed");
                Log.w(TAG, "Google sign in failed", e);
            }
        }
    }

    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            getSocietyDetails(user.getEmail());
                        } else {
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                        }
                    }
                });
    }

    public void On_Register(View view) {
        startActivity(new Intent(getApplicationContext(), RegisterActivity.class));
    }

    public void On_ForgotPass(View view) {
        startActivity(new Intent(getApplicationContext(), ForgotPassActivity.class));
    }
}