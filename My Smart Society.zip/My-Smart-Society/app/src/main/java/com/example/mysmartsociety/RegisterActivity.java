package com.example.mysmartsociety;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.mysmartsociety.AppUtils.CheckInternetConnectivity;
import com.example.mysmartsociety.AppUtils.ToastUtils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class RegisterActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;

    EditText EdtEmail, EdtPass, EdtConfirmPass;
    private ProgressDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mDialog = new ProgressDialog(this);
        EdtEmail=findViewById(R.id.edt_email);
        EdtPass=findViewById(R.id.edt_pass);
        EdtConfirmPass=findViewById(R.id.edt_confirm_pass);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
    }

    public void On_Register(View view) {
        String mEmail = EdtEmail.getText().toString().trim();
        String mPass = EdtPass.getText().toString().trim();
        String mCPass = EdtConfirmPass.getText().toString().trim();
        if(TextUtils.isEmpty(mEmail)) {
            EdtEmail.setError("Please enter email!");
            return;
        }else if(TextUtils.isEmpty(mPass) || mPass.length()== 5){
            EdtPass.setError("Enter atleast 6 char proper password!");
            return;
        }
        else if(!mPass.equals(mCPass)){
            EdtConfirmPass.setError("Please enter proper confirm password!");
            return;
        }

        if (CheckInternetConnectivity.isInternet(RegisterActivity.this)) {
        mDialog.setMessage("Registering...");
        mDialog.show();
        mAuth.createUserWithEmailAndPassword(mEmail,mPass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                ToastUtils.showToastShort(RegisterActivity.this,"Taks intialized");
                if(task.isSuccessful()){
                    sendEmailVerification();
                    ToastUtils.showToastLong(RegisterActivity.this,"Registered Successfully!");
                    finish();
                    super.getClass();
                }else{
                    ToastUtils.showToastLong(RegisterActivity.this,"Something went wrong!");
                }
                mDialog.dismiss();
            }
        });
        }else{
            ToastUtils.showToastLong(RegisterActivity.this,"No Internet Connection!!!");
        }
    }

    private void sendEmailVerification() {
        FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();
        if (user!=null)
        {
            user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful())
                    {
                        FirebaseAuth.getInstance().signOut();
                    }

                }
            });
        }
    }

    public void On_Already_Registered(View view) {
        super.getClass();
        this.finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}