package com.example.mysmartsociety.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mysmartsociety.Model.ComplaintUpload;
import com.example.mysmartsociety.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

public class VisitorListAdapter extends RecyclerView.Adapter<VisitorListAdapter.MyViewHolder> {
    ArrayList<Map<String, Object>> mList;
    Context context;

    public VisitorListAdapter(Context context, ArrayList<Map<String, Object>> mList){
        this.mList = mList;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.rv_visitor_item , parent ,false);
        return new MyViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Map<String, Object> map = mList.get(position);
        holder.name.setText(map.get("visitorName").toString());
        holder.reason.setText(map.get("visitorReason").toString());
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM hh:mm:ss");
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(Long.parseLong(map.get("checkInTimestamp").toString()));
        holder.date.setText(formatter.format(calendar.getTime()));
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public static  class MyViewHolder extends RecyclerView.ViewHolder{

        TextView name, reason, date;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.name_text);
            reason = itemView.findViewById(R.id.reason_text);
            date = itemView.findViewById(R.id.date_text);
        }
    }
}
