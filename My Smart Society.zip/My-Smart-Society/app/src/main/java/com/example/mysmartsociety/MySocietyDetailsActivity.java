package com.example.mysmartsociety;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.mysmartsociety.AppUtils.CategoryPreference;

public class MySocietyDetailsActivity extends AppCompatActivity {

    TextView data;
    CategoryPreference cPrefrence;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_society_details);
        data = findViewById(R.id.society_data);
        cPrefrence = CategoryPreference.getInstance(MySocietyDetailsActivity.this);
        String value = "SOCIETY UNIQUE CODE: " + cPrefrence.getData("c_unique_code") +"\n\n"+
                "SOCIETY NAME: " + cPrefrence.getData("c_name") +"\n\n"+
                "SOCIETY ADDRESS: " + cPrefrence.getData("c_add") +"\n\n"+
                "SOCIETY FLATS: " + cPrefrence.getData("c_flats") +"\n\n"+
                "SOCIETY WINGS: " + cPrefrence.getData("c_wings");

        data.setText(value);

    }

    public void On_Go_Back(View view) {
        super.getClass();
        this.finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}