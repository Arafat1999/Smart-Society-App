package com.example.mysmartsociety.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.example.mysmartsociety.R;
import com.example.mysmartsociety.SplashActivity;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;
import java.util.Random;

public class FirebaseCloudMessagingService extends FirebaseMessagingService {
    private String TAG = "FCM_SERVICE";

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        if (remoteMessage.getData() != null) {
            Log.d(TAG, "onMessageReceived: "+remoteMessage.getData());
            if (remoteMessage.getData().size() != 0) {
                Map data = remoteMessage.getData();
                if (data.containsKey("title") && data.containsKey("message")) {
                    String title = (String) data.get("title");
                    String body = (String) data.get("message");
                    showNotification(getApplicationContext(), title, body, 0);
                }
            }
        }
    }

    public static void showNotification(Context context, String title, String body, int NOTIFICATION_ID) {
        if (NOTIFICATION_ID == 0) {
            Random rn = new Random();
            int range = 500;
            NOTIFICATION_ID = rn.nextInt(range);
        }
        String groupKey = "" + NOTIFICATION_ID;
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        boolean vibratePhone = true;
        NotificationCompat.BigTextStyle notiStyle = new NotificationCompat.BigTextStyle();
        notiStyle.setBigContentTitle(title);

        CharSequence bigText = body;
        notiStyle.bigText(bigText);

        Intent resultIntent = new Intent(context, SplashActivity.class);

        PendingIntent resultPendingIntent = PendingIntent.getActivities(context, NOTIFICATION_ID,
                new Intent[]{resultIntent}, PendingIntent.FLAG_ONE_SHOT);

        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(context)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setAutoCancel(true)
                        .setLargeIcon(BitmapFactory.decodeResource(context.getResources(), R.mipmap.ic_launcher))
                        .setContentIntent(resultPendingIntent)
                        .setContentTitle(title)
                        .setContentText(body)
                        .setStyle(notiStyle)
                        .setChannelId("CHANNEL_ID")
                        .setGroup(groupKey)
                        .setSound(defaultSoundUri);
        if (vibratePhone) {
            mBuilder.setDefaults(NotificationCompat.DEFAULT_VIBRATE);
        }
        NotificationManager mNotificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            createNotificationChannel(mNotificationManager);
            mBuilder.setChannelId("CHANNEL_ID");
        }
        mNotificationManager.notify(title, NOTIFICATION_ID, mBuilder.build());
    }

    private static void createNotificationChannel(NotificationManager mNotificationManager) {
        NotificationChannel notificationChannel = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            notificationChannel = new NotificationChannel("CHANNEL_ID",
                    "CHANNEL_NAME", NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.BLUE);
            notificationChannel.setShowBadge(true);
            notificationChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            mNotificationManager.createNotificationChannel(notificationChannel);
        }
    }
}
