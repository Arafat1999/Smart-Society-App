package com.example.mysmartsociety.AppUtils;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static android.content.Context.MODE_PRIVATE;

public class RetrofitInstance {

    public static Retrofit retrofit(Context context) {
        OkHttpClient client = new OkHttpClient.Builder()
                .addNetworkInterceptor(new MyOkHttpInterceptor(context))
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();

         return new Retrofit.Builder()
                .baseUrl("https://fcm.googleapis.com").client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }
}

class MyOkHttpInterceptor implements Interceptor {

    Context context;

    MyOkHttpInterceptor(Context context) {
        this.context = context;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request originalRequest = chain.request();

        Request newRequest = originalRequest.newBuilder()
                .header("Authorization", "key=AAAAwM25pMg:APA91bGuEZd9OSTO4zF9UmxWmRxAD6R76mVcUyBVdKbloqxFqzpGgJvm95p7dnzdCjsGXFsGraehDHdoFLLXCnHHKIFOjWxihGU6HM1maNbzRaZ-A04_kalEQBgjfE_Ow8vwrQg1tyHn")
                .header("Content-Type", "application/json")
                .build();

        return chain.proceed(newRequest);
    }
}
