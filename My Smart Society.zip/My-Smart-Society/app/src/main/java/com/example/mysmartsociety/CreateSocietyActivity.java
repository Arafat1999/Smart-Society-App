package com.example.mysmartsociety;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.mysmartsociety.AppUtils.CategoryPreference;
import com.example.mysmartsociety.AppUtils.CheckInternetConnectivity;
import com.example.mysmartsociety.AppUtils.ToastUtils;
import com.example.mysmartsociety.Model.Upload;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Random;

public class CreateSocietyActivity extends AppCompatActivity {

    EditText societyName, societyAdd, societyFlats, societyWings, ManagerNo, SecretoryNo;
    LinearLayout dialog_layout;
    TextView UniqueId;

    private FirebaseDatabase db = FirebaseDatabase.getInstance();
    private DatabaseReference root = db.getReference().child("society");
    private FirebaseAuth mAuth;

    ProgressBar uploadProgress;
    CategoryPreference cPrefrence;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_society);

        cPrefrence = CategoryPreference.getInstance(CreateSocietyActivity.this);

        uploadProgress  = findViewById(R.id.progress_circular);
        dialog_layout = findViewById(R.id.dialog_layout);
        UniqueId = findViewById(R.id.unique_code);

        societyName = findViewById(R.id.edt_society_name);
        societyAdd = findViewById(R.id.edt_add);
        societyFlats = findViewById(R.id.edt_flats);
        societyWings = findViewById(R.id.edt_wings);
        ManagerNo = findViewById(R.id.edt_manager_no);
        SecretoryNo = findViewById(R.id.edt_secretory_no);


        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
    }

    public void On_save(View view) {

        if (CheckInternetConnectivity.isInternet(CreateSocietyActivity.this)) {
            if(societyName.getText().toString().isEmpty()){
                societyName.setError("Please enter society name!");
            }else if(societyAdd.getText().toString().isEmpty()){
                societyAdd.setError("Enter Society Address!");
            }else if(societyFlats.getText().toString().isEmpty()){
                societyFlats.setError("Enter total flats!");
            }else if(societyWings.getText().toString().isEmpty()){
                societyWings.setError("Enter wings");
            }else if(ManagerNo.getText().toString().isEmpty()){
                ManagerNo.setError("Enter Manager Phone Number!");
            }else if(SecretoryNo.getText().toString().isEmpty()){
                SecretoryNo.setError("Enter Secretory Phone Number!");
            }
            else {
                uploadProgress.setVisibility(View.VISIBLE);

                String email = "";
                if (mAuth.getCurrentUser() !=null)
                    email = mAuth.getCurrentUser().getEmail();

                String Sname = societyName.getText().toString();
                String Sadd = societyAdd.getText().toString();
                String Sflats = societyFlats.getText().toString();
                String Swings = societyWings.getText().toString();
                String manager = "+91"+ ManagerNo.getText().toString();
                String secretory = "+91" + SecretoryNo.getText().toString();

                String i = GenerateRandomString.randomString(6);
                UniqueId.setText(i);

                cPrefrence.saveData("c_unique_code",i);
                cPrefrence.saveData("c_name",Sname);
                cPrefrence.saveData("c_add",Sadd);
                cPrefrence.saveData("c_flats",Sflats);
                cPrefrence.saveData("c_wings",Swings);
                cPrefrence.saveData("c_manager_no",manager);
                cPrefrence.saveData("c_secretory_no",secretory);
                cPrefrence.saveData("c_email",email);


                HashMap<String , String> userMap = new HashMap<>();
                userMap.put("Society_name" , Sname);
                userMap.put("Society_add",Sadd);
                userMap.put("Society_flats" , Sflats);
                userMap.put("Society_wings",Swings);
                userMap.put("Society_manager" , manager);
                userMap.put("Society_secretory",secretory);
                userMap.put("Society_unique_code",i);
                userMap.put("email",email);

                root.child(Sname).setValue(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        uploadProgress.setVisibility(View.GONE);
                        dialog_layout.setVisibility(View.VISIBLE);
                        ToastUtils.showToastShort(CreateSocietyActivity.this,"Society Created successfully");
                    }
                });
            }
        } else {
            ToastUtils.showToastLong(CreateSocietyActivity.this, "No Internet Connection!!!");
        }


    }

    public static class GenerateRandomString {

        public static final String DATA = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        public static Random RANDOM = new Random();

        public static String randomString(int len) {
            StringBuilder sb = new StringBuilder(len);

            for (int i = 0; i < len; i++) {
                sb.append(DATA.charAt(RANDOM.nextInt(DATA.length())));
            }
            return sb.toString();
        }

    }

    public void On_Got_it(View view) {
        dialog_layout.setVisibility(View.GONE);
        cPrefrence.saveData("c_user_type","Secretory");
        startActivity(new Intent(CreateSocietyActivity.this,HomeActivity.class));
        this.finish();
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

}