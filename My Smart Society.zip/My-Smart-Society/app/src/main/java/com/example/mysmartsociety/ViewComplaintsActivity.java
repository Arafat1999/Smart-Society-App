package com.example.mysmartsociety;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import com.example.mysmartsociety.Adapters.ComplaintsAdapter;
import com.example.mysmartsociety.AppUtils.CheckInternetConnectivity;
import com.example.mysmartsociety.AppUtils.ToastUtils;
import com.example.mysmartsociety.Model.ComplaintUpload;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ViewComplaintsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private FirebaseDatabase db = FirebaseDatabase.getInstance();
    private DatabaseReference root = db.getReference().child("member_complaints");
    private ComplaintsAdapter adapter;
    private ArrayList<ComplaintUpload> list;

    ProgressBar mProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_complaints);

        mProgressBar = findViewById(R.id.progress_circular);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();
        adapter = new ComplaintsAdapter(this ,list );

        recyclerView.setAdapter(adapter);

        if (CheckInternetConnectivity.isInternet(ViewComplaintsActivity.this)) {

            root.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                        ComplaintUpload model = dataSnapshot.getValue(ComplaintUpload.class);
                        list.add(0, model);
                    }
                    mProgressBar.setVisibility(View.GONE);
                    adapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    mProgressBar.setVisibility(View.GONE);
                    ToastUtils.showToastShort(ViewComplaintsActivity.this,"Error"+ error);
                }
            });
        } else {
            ToastUtils.showToastLong(ViewComplaintsActivity.this, "No Internet Connection!!!");
        }

    }

    //TODO remaining delete/ resolved complaint button for admin

    public void On_Go_Back(View view) {
        super.getClass();
        this.finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

}